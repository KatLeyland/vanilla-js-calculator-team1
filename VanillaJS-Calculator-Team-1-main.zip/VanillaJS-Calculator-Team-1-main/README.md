# VanillaJS-Calculator-Team-1

Hi Team 1!

Please write your name in this file:

Jorge

Marta

Matthew

Katherine
